from django.contrib import admin
from .models import NGUOIDUNG

# Register your models here.
admin.site.register(NGUOIDUNG)